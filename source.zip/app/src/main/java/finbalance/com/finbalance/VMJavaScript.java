package finbalance.com.finbalance;

import android.content.SharedPreferences;
import android.util.Log;
import android.webkit.JavascriptInterface;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;

/**
 * Created by Магистр on 19.03.2016.
 */
public class VMJavaScript {
    @JavascriptInterface
    public String show(String str){
        Log.i("xxx", str);
        return str;
    }

    @JavascriptInterface
    public String getMessage(){
        return General.message;
    }

    @JavascriptInterface
    public String getData(long secFrm, long secTo){
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        ArrayList<ReportData> obj = new SMSRead(secFrm, secTo).getData();
        if(obj == null) return "null";
        String json = gson.toJson(obj);
        //out(json);
        return json;
    }

    public static final String APP_PREFERENCES = "prf";

    @JavascriptInterface
    public boolean isVal(String fld){
        SharedPreferences share = General.act.getSharedPreferences(APP_PREFERENCES, General.act.MODE_PRIVATE);
        return share.contains(fld);
    }

    @JavascriptInterface
    public String getVal(String fld){
        SharedPreferences share = General.act.getSharedPreferences(APP_PREFERENCES, General.act.MODE_PRIVATE);
        return share.getString(fld, "");
    }

    @JavascriptInterface
    public void setVal(String fld, String val){
        SharedPreferences.Editor edit = General.act.getSharedPreferences(APP_PREFERENCES, General.act.MODE_PRIVATE).edit();
        edit.putString(fld, val);
        edit.apply();
    }

}
