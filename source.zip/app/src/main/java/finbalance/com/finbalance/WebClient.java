package finbalance.com.finbalance;

import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Created by Магистр on 16.03.2016.
 * обработка событий браузера
 */

public class WebClient extends WebViewClient{

    public WebClient() {

    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        view.loadUrl(url);
        return true;
    }
}
