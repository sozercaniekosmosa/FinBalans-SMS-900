package finbalance.com.finbalance;

import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by Магистр on 19.03.2016.
 */
public class SMSRead {

    private ReportBalance report = new ReportBalance();
    private boolean resultEmpty = true;

    public ArrayList<ReportData> getData(){
        return resultEmpty?null:report.getData();
    }

    public SMSRead(long secFrm, long secTo) {

        Cursor res = General.act.getContentResolver().query(
                Uri.parse("content://sms/inbox"),
                new String[]{"date", "address", "body"},
                "address='900' and date < " + ((Long)(secTo*1L)).toString() + " and date >= " + ((Long)(secFrm*1L)).toString(),
                null,
                "date DESC"
        );

        try {

            if (res.moveToFirst() == false) return; // empty box, no ReportBalance
            resultEmpty = false;
            do {
                //out(res.getString(2));
                report.addItData(res.getString(2));
            } while (res.moveToNext());

//            for (ReportData it : report.getData())
//                out(it.name + ": " + it.val.toString());

                //Log.i("xxx", it.name + ": " + it.val.toString());

        } catch (Exception e) {
            Log.e("xxx", e.toString());
        }

    }

}