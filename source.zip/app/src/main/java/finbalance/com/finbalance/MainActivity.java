package finbalance.com.finbalance;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        General.act = this;
        General.web = (WebView)findViewById(R.id.webView);
        General.web.setClickable(true);
        General.web.setSelected(false);
        //General.web.setFocusable(false);
        //General.web.setFocusableInTouchMode(false);
        General.web.getSettings().setJavaScriptEnabled(true);
        General.web.setWebViewClient(new WebClient());
        General.web.loadUrl("file:///android_asset/main.html");
        General.web.addJavascriptInterface(new VMJavaScript(), "VM");
    }

}
