package finbalance.com.finbalance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Магистр on 26.03.2016.
 */

class ReportData {
    public String name = "";
    public Float val = 0.0f;
    public Pattern patt;

    public ReportData(String name, Pattern patt) {
        this.name = name;
        this.val = 0.0f;
        this.patt = patt;
    }

    public Float add(Float val) {
        return this.val += val;
    }
}

public class ReportBalance {

    final int TYPE_CARD = 1;
    final int LAST_NUMB = 2;
    final int DATE = 3;
    final int OPERATION = 4;
    final int SUM = 5;
    final int DESC = 6;
    final int STR_BLN = 7;
    final int TOTAL = 8;

    //    (azs|mts|atm)
    private Pattern patt = Pattern.compile("^(\\D+)(\\d+):?\\s(\\d\\d\\.\\d\\d.\\d\\d\\s?\\d?\\d?:?\\d?\\d?)м?с?к?\\s([A-Za-zА-Яа-яё\\s,\\/\\(\\)\\-]+)(?:[0-9\\/-]*)?\\s(\\d+\\.?\\d?\\d?)\\s?р(?:уб)?\\.?\\s(.*)\\s?(доступно|баланс):\\s(\\d+\\.?\\d?\\d?)\\s?р(?:уб)?\\.?");

    private final ArrayList<ReportData> res = new ArrayList<ReportData>();
    private final Map<String, Integer> map = new HashMap<String, Integer>();


    public ReportBalance() {

        res.add(new ReportData("дебит", null));
        res.add(new ReportData("кредит", null));
        res.add(new ReportData("сальдо", null));
        res.add(new ReportData("остаток", null));
        res.add(new ReportData("зарплата", Pattern.compile(".*(zarplata)")));
        res.add(new ReportData("телефон", Pattern.compile(".*(bee-?line|megafon|mts oao).*")));
        res.add(new ReportData("транспорт", Pattern.compile(".*(azs).*")));
        res.add(new ReportData("продукты", Pattern.compile(".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*")));
        res.add(new ReportData("банкомат", Pattern.compile("^(atm ).*")));
        res.add(new ReportData("строй маг", Pattern.compile("^(leroy|stroitelnyy|yuzhnyy).*")));

        map.put("покупка", -1);
        map.put("списание", -1);
        map.put("зачисление", 1);
        map.put("зачисление пенсии", 1);
        map.put("взыскание/арест по требованию судебных органов", -1);
        map.put("оплата услуг", -1);
        map.put("оплата мобильного банка за ", -1);
        map.put("выдача наличных", -1);
        map.put("возврат покупки", 1);
        map.put("отмена покупки", 1);
        map.put("поправка по счету", 1);
        map.put("оплата услуг на сумму", -1);
        map.put("покупка на сумму", -1);
        map.put("операция списания на сумму", -1);
        map.put("поправка по счету на сумму", 1);
        map.put("операция зачисления на сумму", 1);
        map.put("выдача наличных на сумму", -1);
    }

    public ArrayList<ReportData> getData() {
        return res;
    }

    public void addItData(String str) {

        String typeCard = "";
        Integer lastNumb = 0;
        String date = "";
        String operation = "";
        Float sum = 0f;
        String desc = "";
        String strBal = "";
        String total = "";
        int sign = 0;

        Matcher m = patt.matcher(str.toLowerCase());
        if (m.find()) {

            if (map.containsKey(m.group(OPERATION))) {

                typeCard = m.group(TYPE_CARD);
                lastNumb = Integer.parseInt(m.group(LAST_NUMB));
                date = m.group(DATE);
                operation = m.group(OPERATION);
                sum = Float.parseFloat(m.group(SUM));
                sign = map.get(m.group(OPERATION));
                desc = m.group(DESC);
                strBal = m.group(STR_BLN);
                total = m.group(TOTAL);

                for (ReportData it : res)
                    switch (it.name) {
                        case "дебит":
                            if (sign > 0) it.add(sum);
                            continue;
                        case "кредит":
                            if (sign < 0) it.add(sum * sign);
                            continue;
                        case "сальдо":
                            it.add(sum * sign);
                            continue;
                        case "остаток":
                            if (it.val == 0) it.add(Float.parseFloat(total));
                            continue;
                        default:
                            if ((it.patt != null) && (it.patt.matcher(desc).find()))
                                it.add(sum * sign);
                            continue;
                    }
            } else {
            General.message = "обновите приложение \"" + m.group(OPERATION) + "\"";
            }

        }

    }

}
