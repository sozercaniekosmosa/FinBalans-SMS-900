package finbalance.com.finbalance;

import android.webkit.WebView;

/**
 * Created by Магистр on 19.03.2016.
 */
public class General {
    public static WebView web;
    public static MainActivity act;
    public static String message;
}
