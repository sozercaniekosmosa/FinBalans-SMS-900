package finbalance.com.finbalance;

import android.util.Log;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Магистр on 20.03.2016.
 */
public class Utils {

    private static final Map<Character, String> map = new HashMap<Character, String>();

    static {
        map.put('А', "A");
        map.put('Б', "B");
        map.put('В', "V");
        map.put('Г', "G");
        map.put('Д', "D");
        map.put('Е', "E");
        map.put('Ё', "E");
        map.put('Ж', "Zh");
        map.put('З', "Z");
        map.put('И', "I");
        map.put('Й', "I");
        map.put('К', "K");
        map.put('Л', "L");
        map.put('М', "M");
        map.put('Н', "N");
        map.put('О', "O");
        map.put('П', "P");
        map.put('Р', "R");
        map.put('С', "S");
        map.put('Т', "T");
        map.put('У', "U");
        map.put('Ф', "F");
        map.put('Х', "H");
        map.put('Ц', "C");
        map.put('Ч', "Ch");
        map.put('Ш', "Sh");
        map.put('Щ', "Sh");
        map.put('Ъ', "'");
        map.put('Ы', "Y");
        map.put('Ь', "'");
        map.put('Э', "E");
        map.put('Ю', "U");
        map.put('Я', "Ya");
        map.put('а', "a");
        map.put('б', "b");
        map.put('в', "v");
        map.put('г', "g");
        map.put('д', "d");
        map.put('е', "e");
        map.put('ё', "e");
        map.put('ж', "zh");
        map.put('з', "z");
        map.put('и', "i");
        map.put('й', "i");
        map.put('к', "k");
        map.put('л', "l");
        map.put('м', "m");
        map.put('н', "n");
        map.put('о', "o");
        map.put('п', "p");
        map.put('р', "r");
        map.put('с', "s");
        map.put('т', "t");
        map.put('у', "u");
        map.put('ф', "f");
        map.put('х', "h");
        map.put('ц', "c");
        map.put('ч', "ch");
        map.put('ш', "sh");
        map.put('щ', "sh");
        map.put('ъ', "'");
        map.put('ы', "y");
        map.put('ь', "'");
        map.put('э', "e");
        map.put('ю', "u");
        map.put('я', "ya");

    }

    public static String getTranslt(String str) {
        StringBuilder bld = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            Character ch = str.charAt(i);
            String c = map.get(ch);
            bld.append((c == null) ? ch : c);
        }
        return bld.toString();
    }

    public static float getf2dgt(float f) {
        return Math.round(f * 100) / 100f;
    }

    public static void out(Object o) {
        Log.i("xxx", o.toString());
    }

    public static String getStrDay(int count) {
        String one = "день";
        String two = "дня";
        String five = "дней";

        if (count > 100)
            count %= 100;

        if (count > 20)
            count %= 10;

        switch (count) {
            case 1:
                return one;
            case 2:
            case 3:
            case 4:
                return two;
            default:
                return five;
        }
    }



}
