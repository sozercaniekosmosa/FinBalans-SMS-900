/**
 * Created by Магистр on 16.04.2016.
 */

function log(txt){
	$('#mess').text(txt);
}

Date.prototype.addDay = function(d){
	this.setDate(this.getDate()+d);
	return this;
}

Date.prototype.addMonth = function(m){
	this.setMonth(this.getMonth()+m);
	return this;
}

Date.prototype.addYear = function(yr){
	this.setFullYear(this.getFullYear()+yr);
	return this;
}

Date.prototype.setDay = function(d){
	this.setDate(d);
	return this;
}

Date.prototype.setYr = function(yr){
	this.setFullYear(yr);
	return this;
}

Date.prototype.setMnt = function(m){
	this.setMonth(m);
	return this;
}

Date.prototype.setH = function(h){
	this.setHours(h);
	return this;
}

Date.prototype.setM = function(m){
	this.setMinutes(m);
	return this;
}

Date.prototype.setS = function(s){
	this.setSeconds(s);
	return this;
}

Date.prototype.timeReset = function(){
	this.setHours(0);
	this.setMinutes(0);
	this.setSeconds(0);
	return this;
}

Array.prototype.all = function (fn) {
	var len = this.length;
	for (var i = 0; i < len; i++) {
		fn(this[i], i);
	}
}

var mont = [
	'январь',
	'февраль',
	'март',
	'апрель',
	'май',
	'июнь',
	'июль',
	'август',
	'сентябрь',
	'октябрь',
	'ноябрь',
	'декабрь'
];

var translit = function(text) {
	text = text
		.replace(/\u0401/g, 'YO')
		.replace(/\u0419/g, 'I')
		.replace(/\u0426/g, 'TS')
		.replace(/\u0423/g, 'U')
		.replace(/\u041A/g, 'K')
		.replace(/\u0415/g, 'E')
		.replace(/\u041D/g, 'N')
		.replace(/\u0413/g, 'G')
		.replace(/\u0428/g, 'SH')
		.replace(/\u0429/g, 'SCH')
		.replace(/\u0417/g, 'Z')
		.replace(/\u0425/g, 'H')
		.replace(/\u042A/g, '')
		.replace(/\u0451/g, 'yo')
		.replace(/\u0439/g, 'i')
		.replace(/\u0446/g, 'ts')
		.replace(/\u0443/g, 'u')
		.replace(/\u043A/g, 'k')
		.replace(/\u0435/g, 'e')
		.replace(/\u043D/g, 'n')
		.replace(/\u0433/g, 'g')
		.replace(/\u0448/g, 'sh')
		.replace(/\u0449/g, 'sch')
		.replace(/\u0437/g, 'z')
		.replace(/\u0445/g, 'h')
		.replace(/\u044A/g, "_")
		.replace(/\u0424/g, 'F')
		.replace(/\u042B/g, 'I')
		.replace(/\u0412/g, 'V')
		.replace(/\u0410/g, 'a')
		.replace(/\u041F/g, 'P')
		.replace(/\u0420/g, 'R')
		.replace(/\u041E/g, 'O')
		.replace(/\u041B/g, 'L')
		.replace(/\u0414/g, 'D')
		.replace(/\u0416/g, 'ZH')
		.replace(/\u042D/g, 'E')
		.replace(/\u0444/g, 'f')
		.replace(/\u044B/g, 'i')
		.replace(/\u0432/g, 'v')
		.replace(/\u0430/g, 'a')
		.replace(/\u043F/g, 'p')
		.replace(/\u0440/g, 'r')
		.replace(/\u043E/g, 'o')
		.replace(/\u043B/g, 'l')
		.replace(/\u0434/g, 'd')
		.replace(/\u0436/g, 'zh')
		.replace(/\u044D/g, 'e')
		.replace(/\u042F/g, 'Ya')
		.replace(/\u0427/g, 'CH')
		.replace(/\u0421/g, 'S')
		.replace(/\u041C/g, 'M')
		.replace(/\u0418/g, 'I')
		.replace(/\u0422/g, 'T')
		.replace(/\u042C/g, "'")
		.replace(/\u0411/g, 'B')
		.replace(/\u042E/g, 'YU')
		.replace(/\u044F/g, 'ya')
		.replace(/\u0447/g, 'ch')
		.replace(/\u0441/g, 's')
		.replace(/\u043C/g, 'm')
		.replace(/\u0438/g, 'i')
		.replace(/\u0442/g, 't')
		.replace(/\u044C/g, "_")
		.replace(/\u0431/g, 'b')
		.replace(/\u044E/g, 'yu')
		.replace(/\u002E/g, '_')
		.replace(/\s/g, '_');

	return text;
};


function setAttr(it, valNow, valBfr) {
	it.text(getNorm(valNow - valBfr));
	it.css({
		'color':     (valNow < valBfr ? 'hsl(10, 100%, 36%)' : 'rgb(92, 134, 0)')
	});
	it.addClass('bfr-inx');
	it.text((valNow < valBfr ? '▼' : '▲') + it.text());

	return it;
}

function getNorm(f) {
	f = Math.round(f);

	f = Math.abs(f);
	if ((f > 999) && (f <= 9999))        return Math.floor(f / 100) / 10 + 'k';
	if ((f > 9999) && (f <= 99999))      return Math.floor(f / 1000) + 'k';
	if ((f > 99999) && (f <= 999999))    return Math.floor(f / 1000) + 'k';
	if ((f > 999999) && (f <= 9999999))  return Math.floor(f / 100000) / 10 + 'M';
	if (f > 9999999)                     return Math.floor(f / 1000000) + 'M';

	return f;
}