/**
 * Created by Магистр on 16.04.2016.
 */


var data = [];

var fps = 1 / 5;

var tstArr = [
	'[{"name":"дебит","val":0.0},{"name":"кредит","val":-7773.4},{"name":"сальдо","val":6.6},{"name":"остаток","val":25.98},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-400.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-1400.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-59.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-800.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":7.125},{"name":"кредит","val":-48738.77},{"name":"сальдо","val":8.35},{"name":"остаток","val":99.38},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":7.12},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-650.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-3700.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-6681.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-17600.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-1566.22}]',
	'[{"name":"дебит","val":7.0},{"name":"кредит","val":-42836.11},{"name":"сальдо","val":0.891},{"name":"остаток","val":1.03},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":6.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-592.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-2700.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-6030.5},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-4500.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-7670.0}]',
	'[{"name":"дебит","val":3.71},{"name":"кредит","val":-64094.76},{"name":"сальдо","val":-29611.05},{"name":"остаток","val":4.14},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":3.71},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-700.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-5785.81},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-8481.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-26300.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-2927.0}]',
	'[{"name":"дебит","val":45.84},{"name":"кредит","val":-103381.055},{"name":"сальдо","val":4.79},{"name":"остаток","val":7.86},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":5.85},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-1735.67},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-5486.39},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-12004.84},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-9900.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-19439.0}]',
	'[{"name":"дебит","val":9.91},{"name":"кредит","val":-19748.03},{"name":"сальдо","val":-2698.1191},{"name":"остаток","val":3.07},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-830.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-999.97},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-1871.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":0.0},{"name":"кредит","val":-51541.918},{"name":"сальдо","val":-30941.918},{"name":"остаток","val":3.51},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-843.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-1000.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-3517.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-37200.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":4.15},{"name":"кредит","val":-32830.25},{"name":"сальдо","val":-9396.1},{"name":"остаток","val":5.43},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-1860.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-1999.9199},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-2617.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-1600.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-786.0}]',
	'[{"name":"дебит","val":2.85},{"name":"кредит","val":-116594.17},{"name":"сальдо","val":-24241.32},{"name":"остаток","val":1.53},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":2.85},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-1600.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-999.69},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-962.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-383.0}]',
	'[{"name":"дебит","val":59.73},{"name":"кредит","val":-165723.14},{"name":"сальдо","val":6.59},{"name":"остаток","val":2.85},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":9.734},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-600.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-3034.97},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-8417.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-84300.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":4.52},{"name":"кредит","val":-57869.656},{"name":"сальдо","val":0.871},{"name":"остаток","val":3.7},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":4.52},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-500.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":0.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-4313.14},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-5000.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-698.0}]',
	'[{"name":"дебит","val":9.492},{"name":"кредит","val":-60200.38},{"name":"сальдо","val":-2800.8896},{"name":"остаток","val":7.83},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-613.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-1000.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-4058.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-3300.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":4.0},{"name":"кредит","val":-46162.34},{"name":"сальдо","val":0.6602},{"name":"остаток","val":0.72},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":4.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-300.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-3000.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-4827.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-2500.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":4.0},{"name":"кредит","val":-55303.117},{"name":"сальдо","val":0.87964},{"name":"остаток","val":0.06},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":4.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-595.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-2000.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-5950.4},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-3400.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":4.0},{"name":"кредит","val":-61696.21},{"name":"сальдо","val":-13072.209},{"name":"остаток","val":4.18},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":4.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-250.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-3000.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-7630.8203},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-2955.3}]',
	'[{"name":"дебит","val":4.92},{"name":"кредит","val":-39729.52},{"name":"сальдо","val":-6054.597},{"name":"остаток","val":6.39},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":4.92},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-600.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-3000.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-8890.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-2000.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-155.0}]',
	'[{"name":"дебит","val":671.0},{"name":"кредит","val":-55107.445},{"name":"сальдо","val":563.549},{"name":"остаток","val":750.99},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":624.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-267.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-1299.87},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-1275.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-3000.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":178.2},{"name":"кредит","val":-44064.82},{"name":"сальдо","val":13.379},{"name":"остаток","val":17.44},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":378.2},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-100.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":0.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-189.97},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-2000.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":220.35},{"name":"кредит","val":-61174.28},{"name":"сальдо","val":-8953.93},{"name":"остаток","val":4.06},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":220.35},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-536.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":0.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-2031.51},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-11800.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":526.383},{"name":"кредит","val":-42319.9},{"name":"сальдо","val":-1793.5186},{"name":"остаток","val":17.99},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":726.383},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-1091.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-999.88},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-6688.45},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-8400.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-1570.22}]',
	'[{"name":"дебит","val":237.8},{"name":"кредит","val":-82407.21},{"name":"сальдо","val":30.58},{"name":"остаток","val":241.51},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":048.8},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-500.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-2000.1},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-6801.6797},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-11100.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-3182.0}]',
	'[{"name":"дебит","val":193.01},{"name":"кредит","val":-23316.342},{"name":"сальдо","val":-5123.33},{"name":"остаток","val":0.93},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":91.01},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-700.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":0.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-189.9},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-5500.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":224.0},{"name":"кредит","val":-77211.66},{"name":"сальдо","val":-28987.65},{"name":"остаток","val":94.26},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":724.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-550.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-1999.94},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-10113.399},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-398.0}]',
	'[{"name":"дебит","val":344.0},{"name":"кредит","val":-78410.19},{"name":"сальдо","val":933.809},{"name":"остаток","val":911.91},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":924.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-700.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-1999.94},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-2701.5},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":-10680.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":593.56},{"name":"кредит","val":-58318.902},{"name":"сальдо","val":74.6484},{"name":"остаток","val":008.1},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":593.56},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-1000.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-1999.94},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":0.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":724.0},{"name":"кредит","val":-35053.88},{"name":"сальдо","val":670.121},{"name":"остаток","val":763.45},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":724.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-502.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-1098.92},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-316.8},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-257.0}]',
	'[{"name":"дебит","val":724.0},{"name":"кредит","val":-44457.055},{"name":"сальдо","val":266.948},{"name":"остаток","val":3.33},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":724.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-720.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-1300.2},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-1510.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-7918.0}]',
	'[{"name":"дебит","val":252.2},{"name":"кредит","val":-48136.51},{"name":"сальдо","val":-17884.313},{"name":"остаток","val":0.53},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-573.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-1400.0901},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-1565.2},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":824.0},{"name":"кредит","val":-37288.41},{"name":"сальдо","val":535.591},{"name":"остаток","val":914.84},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-300.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-999.8},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-1729.4},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-1223.0}]',
	'[{"name":"дебит","val":477.9},{"name":"кредит","val":-56600.33},{"name":"сальдо","val":-122.42969},{"name":"остаток","val":113.6},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-550.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-3000.48},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-3864.5},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":-197.5}]',
	'[{"name":"дебит","val":224.0},{"name":"кредит","val":-43201.563},{"name":"сальдо","val":022.439},{"name":"остаток","val":282.53},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-860.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-999.83},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-2309.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":579.78},{"name":"кредит","val":-47007.117},{"name":"сальдо","val":2.6621},{"name":"остаток","val":90.09},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-1350.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-2000.02},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-3237.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":952.61},{"name":"кредит","val":-45203.703},{"name":"сальдо","val":-16251.091},{"name":"остаток","val":7.43},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-2350.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-999.87},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-900.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":519.0},{"name":"кредит","val":-102760.98},{"name":"сальдо","val":-14241.979},{"name":"остаток","val":042.52},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":-2790.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":-2000.08},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":-399.9},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]',
	'[{"name":"дебит","val":0.0},{"name":"кредит","val":0.0},{"name":"сальдо","val":0.0},{"name":"остаток","val":0.0},{"name":"зарплата","patt":{"pattern":".*(zarplata)","flags":0},"val":0.0},{"name":"телефон","patt":{"pattern":".*(bee-?line|megafon|mts oao).*","flags":0},"val":0.0},{"name":"транспорт","patt":{"pattern":".*(azs).*","flags":0},"val":0.0},{"name":"продукты","patt":{"pattern":".*(o ?key|magnit|lenta|auchan|monetka|karusel|metro).*","flags":0},"val":0.0},{"name":"банкомат","patt":{"pattern":"^(atm ).*","flags":0},"val":0.0},{"name":"строй маг","patt":{"pattern":"^(leroy|stroitelnyy|yuzhnyy).*","flags":0},"val":0.0}]'
];

var pos;
var cntMonth = 0;
var mdlSumm;
var cnt_mnt;

function addData(frm, to) {
	var res;
	var vrfVal = 0;
	if (window['VM'] == undefined) { //TODO: при реальном использовании заменить на !=
		res = JSON.parse(VM.getData(frm.getTime(), to.getTime()));
	} else {
		var str = tstArr[pos++];
		if (str == undefined) return;
		res = JSON.parse(str);
	}
	if (res instanceof Array) {
		cnt_mnt++;
		var len = res.length;
		for (var i = 0; i < len; i++) {
			vrfVal += res[i].val;
		}

		if (vrfVal != 0) {
			data.push(mont[frm.getMonth()] + "\'" + (frm.getFullYear() + '').substring(2));
			data.push(res);
		}
	}
}


function setRangMonth(dir) {
	if (dir < 0) if (cntMonth > 1) {
		cntMonth--;
		if (window['VM'] != undefined) VM.setVal('cntMonth', cntMonth);
		upd();
	}
	;
	if (dir > 0) if (cntMonth < 12) {
		cntMonth++;
		if (window['VM'] != undefined) VM.setVal('cntMonth', cntMonth);
		upd();
	}
	;
	$('#cm').val(cntMonth);
}

if (window['VM'] != undefined) {
	if (VM.isVal('cntMonth') === false) VM.setVal('cntMonth', 3);
	cntMonth = VM.getVal('cntMonth');
} else {
	cntMonth = 12;
}

setRangMonth(0);

function upd() {

	pos = 0;
	cnt_mnt = 0;
	mdlSumm = [];
	$('#tbl').remove();
	$('#desc').empty();
	data = [];

	var frm = new Date().addMonth(1).setDay(1).timeReset();
	var to = new Date().addMonth(2).setDay(1).timeReset();

	for (i = 0; i < cntMonth; i++) {
		frm.addMonth(-1);
		to.addMonth(-1);
		addData(frm, to);
	}

	$tbl = $('<table>').attr('id', 'tbl');
	$('#dv-tbl').append($tbl);
	$tbl.append($('<tr>').attr('id', 'tr-hdr'));


	$tdsc = $('#desc');
	$tdsc.append(
		$('<tr>').append(
			$('<td>').attr('id', 'btn-menu').text('меню')
		)
	);

	data.all(function (itLst, i) {
		if (!(itLst instanceof Array)) {
			$('#tr-hdr').append($('<td>').text(itLst));
			return;
		}
		var bfr = 0;
		itLst.all(function (it, j) {
			$tr = $('#' + translit(it.name));
			if ($tr.length == 0) {
				$tr = $('<tr>').attr('id', translit(it.name));
				$tbl.append($tr);
				$tdsc.append(
					$('<tr>').addClass('desc-it')
						.append(
							$('<td>').append(
								$('<span>').text(it.name)
							)
								.append(
									$('<span>').attr('id', translit('d-' + it.name)).addClass('bfr-inx')
								)
					)
				);
			}

			var $td = $('<td>');
			var mdl;
			if (mdlSumm['d-' + translit(it.name)] == undefined) mdlSumm['d-' + translit(it.name)] = 0;
			mdlSumm['d-' + translit(it.name)] += it.val;
			if((cnt_mnt == 0)||(mdlSumm['d-' + translit(it.name)] == 0)){
				mdl = '-'
			}else {
				mdl = getNorm(mdlSumm['d-' + translit(it.name)] / cnt_mnt);
			}
			$('#d-' + translit(it.name)).text(mdl);

			$td.append($('<span>').text(getNorm(it.val)));
			if ((i + 2) < data.length) {
				var val = data[i + 2][j].val;
				$td.append(setAttr($('<span>'), it.val, val));
			}
			$tr.append($td);

		});
	});

	$('#btn-menu').click(function (e) {
		var $fm = $('#f-menu');
		if ($fm.css('display') == 'none') {
			$fm.animate({
				left:    "show",
				opacity: "show"
			}, 100);
		} else {
			$fm.animate({
				left:    "hide",
				opacity: "hide"
			}, 100);
		}
	});

}
upd();
//setInterval(upd, 1000 / fps);